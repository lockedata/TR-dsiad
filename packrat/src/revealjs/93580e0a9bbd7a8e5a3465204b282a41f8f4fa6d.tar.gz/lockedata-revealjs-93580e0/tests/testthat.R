library(testthat)
library(revealjs)

test_check("revealjs")
